# 💼 Business Intelligence & Data Analytics Portfolio – [Your Name]

👋 Hi! I'm a seasoned IT professional with 15+ years of experience in functional testing, test management, and data warehouse projects. I’m now focused on transitioning into Data Analytics and Business Intelligence roles.

This portfolio showcases my hands-on projects with Power BI, SQL, and data storytelling. Each project includes real business use cases, visual dashboards, and actionable insights.

## 📊 Featured Projects

### 🔹 [Sales Performance Dashboard](./PowerBI-Dashboards/Sales-Performance/)
> Analyze sales and profit trends, top-performing categories, and regional performance using Power BI and DAX.

### 🔹 [HR Attrition Analysis](./PowerBI-Dashboards/HR-Attrition-Analysis/)
> Explore employee attrition causes using HR analytics data and build executive-level reporting dashboards.

### 🔹 [Customer Churn SQL Analysis](./SQL-Projects/CustomerChurn-SQLQueries.sql)
> Use SQL to investigate churn patterns and recommend retention strategies based on customer behavior.

## 🚀 Tools & Technologies
- Power BI Desktop (DAX, Data Modeling, Visualizations)
- SQL (Joins, Aggregations, CTEs, Window Functions)
- Excel, CSV, and open datasets
- Data Storytelling and KPI Reporting
- Version control with GitHub

## 📩 Let's Connect
- 💼 [LinkedIn](https://www.linkedin.com/in/your-profile)
- 📧 [Email Me](mailto:your.email@example.com)
