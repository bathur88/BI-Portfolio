# 📈 Sales Performance Dashboard (Power BI)

## 🧠 Business Scenario
A retail company needs to monitor sales performance across different regions, product categories, and customer segments. The goal is to make data-driven decisions on promotions and inventory.

## 📁 Dataset
- Source: Superstore Dataset (Kaggle)
- 10,000+ sales records including region, segment, category, and profit.

## 📊 Dashboard Features
- Total Sales, Profit, Quantity Sold
- Sales by Region and Segment
- Year-over-Year and Month-over-Month Growth
- Filters by Category, Year, Customer Segment
- Time-based visualizations (line and bar charts)

## 📸 Dashboard Preview

![Sales Dashboard Screenshot](./images/sales-dashboard.png)

## 🛠️ Tools & Techniques
- Power BI
- DAX: CALCULATE, TOTALYTD, DATEADD, SUMX
- Data Modeling: Star schema (Fact + Dimension tables)
- Power Query: Data cleaning and transformation

## ✅ Key Takeaways
- Sales have increased YoY in the East and South regions
- Office Supplies have the highest sales but lowest profit margin
- Small Business segment shows rising trend and retention potential

## 📂 Files Included
- SalesPerformance.pbix – Power BI report file
- images/ – Dashboard screenshot(s)
- README.md – Project overview

## 👤 Author
**[Your Name]** – BI/QA Professional transitioning into data analytics.
📩 your.email@example.com | 💼 LinkedIn
