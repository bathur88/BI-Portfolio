# SQL Projects

This folder contains SQL scripts and documentation for data analysis tasks such as customer churn, retention, and more.